"use client";

import useSWR from "swr";
import { useState } from "react";
import { ChevronDown } from "lucide-react";
import { Badge, Card, CardTitle } from "@/components/ui";
import type { ConvictionCall } from "@/db/schema";
import { POSTURE_LABEL, type Posture } from "@/lib/conviction-labels";
// CycleStatsRow ya trae su propia etiqueta: asi el panel no importa
// crypto-cycle (que arrastra la descarga de historicos al bundle del navegador).
import type { CycleStatsRow, PostureStats, SpecialStats } from "@/lib/conviction-calls";
import { api, cn, fmtDate } from "@/lib/utils";

type History = { calls: ConvictionCall[]; stats: PostureStats[]; cycleStats: CycleStatsRow[]; specialStats?: SpecialStats; asOf: number };

const fetcher = async (url: string) => {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
};

const HORIZONS = [30, 90, 180, 365] as const;

function label(p: PostureStats["posture"]): string {
  return p === "benchmark" ? "Indice (VOO)" : POSTURE_LABEL[p as Posture];
}

/** Etiqueta de una fila suelta, que puede ser de bolsa, indice o ciclo cripto. */
const CYCLE_LABEL: Record<string, string> = {
  cycle_extra: "Aporte extra",
  cycle_normal: "Aporte normal",
  cycle_light: "Aporte reducido",
  cycle_hold: "Tramo retenido",
};

function callLabel(c: ConvictionCall): string {
  if (c.kind === "benchmark") return "Indice";
  if (c.kind === "cycle") return CYCLE_LABEL[c.posture] ?? c.posture;
  if (c.kind === "special") return "Apuesta";
  return POSTURE_LABEL[c.posture as Posture] ?? c.posture;
}

function callTone(c: ConvictionCall): "up" | "down" | "warn" | "neutral" | "accent" {
  if (c.kind === "benchmark") return "neutral";
  if (c.kind === "cycle") {
    return c.posture === "cycle_extra" ? "up" : c.posture === "cycle_hold" ? "warn" : "accent";
  }
  if (c.kind === "special") return "accent";
  if (c.posture === "buy" || c.posture === "strong_buy") return "up";
  if (c.posture === "hold") return "accent";
  if (c.posture === "reduce") return "warn";
  return "down";
}

function Ret({ v }: { v: number | null }) {
  if (v === null) return <span className="text-faint">–</span>;
  return (
    <span className={cn("tnum", v > 0 && "text-up", v < 0 && "text-down")}>
      {v > 0 ? "+" : ""}
      {v}%
    </span>
  );
}

/**
 * Historial del oraculo: lo que dijo, cuando, y como le fue. La credibilidad
 * del sistema es esta tabla, no su elocuencia. Los retornos se rellenan solos
 * cuando vence cada plazo (job nocturno).
 */
export function HistoryCard({ refreshKey = 0 }: { refreshKey?: number }) {
  const { data, error, isLoading } = useSWR<History>(api(`/api/conviction/history?k=${refreshKey}`), fetcher, {
    revalidateOnFocus: false,
  });
  const [open, setOpen] = useState(false);

  const stats = (data?.stats ?? []).filter((s) => s.n > 0);
  const cycle = (data?.cycleStats ?? []).filter((s) => s.n > 0);
  const special = data?.specialStats && data.specialStats.n > 0 ? data.specialStats : null;
  const anyDue = stats.some((s) => HORIZONS.some((h) => s.counts[h] > 0));

  return (
    <Card>
      <CardTitle>Historial del oraculo</CardTitle>
      {isLoading && <p className="text-sm text-muted">Cargando...</p>}
      {error && <p className="text-sm text-down">{(error as Error).message}</p>}
      {data && data.calls.length === 0 && (
        <p className="text-sm text-muted">
          Todavia no hay llamadas registradas. Genera el plan del mes y guardalo: a partir de
          ahi cada llamada se mide a 30, 90, 180 y 365 dias.
        </p>
      )}

      {stats.length > 0 && (
        <>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs text-faint">
                  <th className="py-1.5 pr-3 font-medium">Postura</th>
                  <th className="py-1.5 pr-3 font-medium tnum">N</th>
                  {HORIZONS.map((h) => (
                    <th key={h} className="py-1.5 pr-3 font-medium">
                      {h}d
                    </th>
                  ))}
                  <th className="py-1.5 font-medium">Acierto</th>
                </tr>
              </thead>
              <tbody>
                {stats.map((s) => (
                  <tr key={s.posture} className="border-t border-border">
                    <td className="py-2 pr-3 font-medium">{label(s.posture)}</td>
                    <td className="py-2 pr-3 tnum text-muted">{s.n}</td>
                    {HORIZONS.map((h) => (
                      <td key={h} className="py-2 pr-3">
                        <Ret v={s.avg[h]} />
                        {s.counts[h] > 0 && <span className="ml-1 text-[10px] text-faint">({s.counts[h]})</span>}
                      </td>
                    ))}
                    <td className="py-2">
                      {s.hitRate[90] !== null ? (
                        <span className="tnum">{s.hitRate[90]}% a 90d</span>
                      ) : s.hitRate[30] !== null ? (
                        <span className="tnum">{s.hitRate[30]}% a 30d</span>
                      ) : (
                        <span className="text-faint">–</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {!anyDue && (
            <p className="mt-2 text-xs text-faint">
              Aun no ha vencido ningun plazo: los retornos apareceran a los 30 dias de la primera llamada.
            </p>
          )}
          <p className="mt-2 text-xs text-faint">
            Retorno medio del precio desde la llamada. Acierto: en compras, que subiera; en recortes y ventas,
            que cayera. El indice es la referencia a batir en el mismo periodo.
          </p>
        </>
      )}

      {cycle.length > 0 && (
        <div className="mt-5">
          <h4 className="mb-2 text-xs font-semibold uppercase tracking-wide text-faint">
            Ciclo cripto · se mide aparte
          </h4>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs text-faint">
                  <th className="py-1.5 pr-3 font-medium">Decision</th>
                  <th className="py-1.5 pr-3 font-medium tnum">N</th>
                  {HORIZONS.map((h) => (
                    <th key={h} className="py-1.5 pr-3 font-medium">
                      {h}d
                    </th>
                  ))}
                  <th className="py-1.5 font-medium">Acierto</th>
                </tr>
              </thead>
              <tbody>
                {cycle.map((s) => (
                  <tr key={s.posture} className="border-t border-border">
                    <td className="py-2 pr-3 font-medium">{s.label}</td>
                    <td className="py-2 pr-3 tnum text-muted">{s.n}</td>
                    {HORIZONS.map((h) => (
                      <td key={h} className="py-2 pr-3">
                        <Ret v={s.avg[h]} />
                        {s.counts[h] > 0 && <span className="ml-1 text-[10px] text-faint">({s.counts[h]})</span>}
                      </td>
                    ))}
                    <td className="py-2">
                      {s.hitRate[90] !== null ? (
                        <span className="tnum">{s.hitRate[90]}% a 90d</span>
                      ) : s.hitRate[30] !== null ? (
                        <span className="tnum">{s.hitRate[30]}% a 30d</span>
                      ) : (
                        <span className="text-faint">–</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="mt-2 text-xs text-faint">
            Aqui acertar es distinto: en un aporte extra, que subiera; en un tramo retenido o un aporte reducido
            cerca del maximo, que siguiera cayendo. Es la unica forma de saber si esperar la senal vale la pena.
          </p>
        </div>
      )}


      {special && (
        <div className="mt-5">
          <h4 className="mb-2 text-xs font-semibold uppercase tracking-wide text-faint">
            Apuestas (situaciones especiales) · se miden como cesta
          </h4>
          <div className="flex flex-wrap gap-x-6 gap-y-1 text-sm">
            <span>
              <span className="text-faint">N</span> <span className="tnum">{special.n}</span>
            </span>
            {HORIZONS.map((h) => (
              <span key={h}>
                <span className="text-faint">{h}d</span> <Ret v={special.avg[h]} />
                {special.hitRate[h] !== null && <span className="ml-1 text-xs text-faint">({special.hitRate[h]}% suben)</span>}
              </span>
            ))}
            {special.best90 !== null && (
              <span>
                <span className="text-faint">mejor/peor a 90d</span> <Ret v={special.best90} /> / <Ret v={special.worst90} />
              </span>
            )}
          </div>
          <p className="mt-2 text-xs text-faint">
            Una apuesta acierta si sube. En una cesta, la distribucion importa mas que la media: una que
            hace +180% paga por varias que se van a cero. La tasa de acierto real de este detector no se
            conoce hasta que haya filas vencidas; hasta entonces es criterio, no medida.
          </p>
        </div>
      )}

      {data && data.calls.length > 0 && (
        <div className="mt-4">
          <button
            onClick={() => setOpen((v) => !v)}
            className="flex items-center gap-1 text-xs text-faint transition hover:text-muted"
          >
            <ChevronDown size={12} className={cn("transition", open && "rotate-180")} />
            Llamadas recientes ({data.calls.length})
          </button>
          {open && (
            <ul className="mt-2 divide-y divide-border rounded-lg border border-border">
              {data.calls.slice(0, 60).map((c) => (
                <li key={c.id} className="flex flex-wrap items-center gap-x-3 gap-y-1 px-3 py-1.5 text-xs">
                  <span className="w-20 text-faint">{fmtDate(c.calledAt)}</span>
                  <span className="w-14 font-semibold">{c.symbol}</span>
                  <Badge tone={callTone(c)}>{callLabel(c)}</Badge>
                  {c.planAmount !== null && c.planAmount > 0 && (
                    <span className="tnum text-muted">${Math.round(c.planAmount)}</span>
                  )}
                  <span className="ml-auto flex gap-3">
                    {HORIZONS.map((h) => {
                      const v = h === 30 ? c.ret30 : h === 90 ? c.ret90 : h === 180 ? c.ret180 : c.ret365;
                      return (
                        <span key={h} className="w-14 text-right">
                          <Ret v={v} />
                        </span>
                      );
                    })}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </Card>
  );
}
